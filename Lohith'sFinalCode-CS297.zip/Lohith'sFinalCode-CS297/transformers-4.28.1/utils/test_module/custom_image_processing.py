from transformers import CLIPImageProcessor


class CustomImageProcessor(CLIPImageProcessor):
    pass
